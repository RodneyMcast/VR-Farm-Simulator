using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;
using Unity.XR.CoreUtils;


public class TractorMount : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private Transform xrCamera; // the HMD camera transform
    [SerializeField] private UnityEngine.XR.Interaction.Toolkit.Interactables.XRGrabInteractable steeringWheelGrab;
    [SerializeField] private Transform seatPoint;
    [SerializeField] private XROrigin xrOrigin; // drag your XR Origin (XR Rig)

    [Header("Optional: disable locomotion while driving")]
    [SerializeField] private Behaviour[] disableWhileDriving; // move/teleport providers etc.

    private Transform originalParent;
    private bool mounted;

    private void OnEnable()
    {
        steeringWheelGrab.selectEntered.AddListener(OnDriveStart);
        steeringWheelGrab.selectExited.AddListener(OnDriveStop);
    }

    private void OnDisable()
    {
        steeringWheelGrab.selectEntered.RemoveListener(OnDriveStart);
        steeringWheelGrab.selectExited.RemoveListener(OnDriveStop);
    }

    private void OnDriveStart(SelectEnterEventArgs args)
{
    if (mounted) return;
    mounted = true;

    if (xrOrigin == null || xrCamera == null || seatPoint == null)
    {
        Debug.LogError("Assign xrOrigin, xrCamera, seatPoint in inspector.");
        return;
    }

    originalParent = xrOrigin.transform.parent;

    // 1) Parent the rig to the seat/tractor WITHOUT keeping world position
    xrOrigin.transform.SetParent(seatPoint, worldPositionStays: false);

    // 2) Reset rig local rotation so it matches the seat direction (yaw only)
    xrOrigin.transform.localRotation = Quaternion.identity;

    // 3) Now align so CAMERA lands exactly on the seatPoint:
    // cameraOffset = camera position relative to rig root (in rig local space)
    Vector3 cameraLocalPos = xrOrigin.transform.InverseTransformPoint(xrCamera.position);

    // Move rig root so camera becomes (0,0,0) in seat space, then seatPoint is camera target.
    xrOrigin.transform.localPosition = -cameraLocalPos;

    // Optional: disable locomotion while driving
    foreach (var b in disableWhileDriving)
        if (b != null) b.enabled = false;
}




   private void OnDriveStop(SelectExitEventArgs args)
{
    if (!mounted) return;
    mounted = false;

    if (xrOrigin == null) return;

    xrOrigin.transform.SetParent(originalParent, worldPositionStays: true);

    foreach (var b in disableWhileDriving)
        if (b != null) b.enabled = true;
}


}
