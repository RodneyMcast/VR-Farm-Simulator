using System.Collections;
using UnityEngine;

public class CowTouchInteract : MonoBehaviour
{
    [Header("Audio")]
    [SerializeField] private AudioSource audioSource;
    [SerializeField] private AudioClip mooClip;

    [Header("Movement Feel")]
    [SerializeField] private float totalDuration = 6.5f;   // keep between 5-8
    [SerializeField] private float moveDistance = 3.0f;    // "a few blocks" (tweak)
    [SerializeField] private float moveSpeedMultiplier = 1f;

    [Header("Turning")]
    [SerializeField] private float turnInterval = 1f;      // every 1 sec
    [SerializeField] private float turnDegrees = 90f;      // 90° steps
    [SerializeField] private int turnSteps = 4;            // 4 turns

    [Header("Trigger")]
    [SerializeField] private string handTag = "PlayerHand";

    private bool isAnimating = false;

    private Vector3 startPos;
    private Quaternion startRot;

    private void OnTriggerEnter(Collider other)
    {
        if (!string.IsNullOrEmpty(handTag) && !other.CompareTag(handTag))
            return;

        if (isAnimating) return;

        StartCoroutine(MoveTurnMooRoutine());
    }

    private IEnumerator MoveTurnMooRoutine()
    {
        isAnimating = true;

        // Lock starting transform so we can return
        startPos = transform.position;
        startRot = transform.rotation;

        // Run 3 parallel routines:
        // 1) turning every second
        // 2) moving forward for totalDuration
        // 3) moo every 3 seconds while moving
        Coroutine turnC = StartCoroutine(TurnRoutine());
        Coroutine mooC  = StartCoroutine(MooRoutine());

        yield return StartCoroutine(MoveRoutine());

        // Stop turn + moo routines (in case they’re mid-wait)
        if (turnC != null) StopCoroutine(turnC);
        if (mooC != null) StopCoroutine(mooC);

        // Return to exact start (position + rotation)
        transform.position = startPos;
        transform.rotation = startRot;

        isAnimating = false;
    }

    private IEnumerator MoveRoutine()
    {
        float t = 0f;

        // We move in the cow's forward direction (changes as it turns)
        // Distance is spread across totalDuration
        float movePerSecond = (moveDistance / totalDuration) * moveSpeedMultiplier;

        while (t < totalDuration)
        {
            transform.position += transform.forward * (movePerSecond * Time.deltaTime);
            t += Time.deltaTime;
            yield return null;
        }
    }

    private IEnumerator TurnRoutine()
{
    // How long each 90° turn takes (smoothness)
    float turnDuration = 0.3f; // tweak: 0.2 snappy, 0.5 very smooth

    for (int i = 0; i < turnSteps; i++)
    {
        // Wait until it's time for the next turn
        yield return new WaitForSeconds(turnInterval);

        Quaternion start = transform.rotation;
        Quaternion target = start * Quaternion.Euler(0f, turnDegrees, 0f);

        float t = 0f;
        while (t < turnDuration)
        {
            t += Time.deltaTime;
            float alpha = Mathf.Clamp01(t / turnDuration);
            transform.rotation = Quaternion.Slerp(start, target, alpha);
            yield return null;
        }

        transform.rotation = target; // ensure it lands exactly
    }
}


    private IEnumerator MooRoutine()
    {
        // Moo immediately, then every 3 seconds while moving
        PlayMoo();

        float elapsed = 0f;
        while (elapsed < totalDuration)
        {
            yield return new WaitForSeconds(3f);
            elapsed += 3f;
            PlayMoo();
        }
    }

    private void PlayMoo()
    {
        if (audioSource != null && mooClip != null)
            audioSource.PlayOneShot(mooClip);
    }
}
