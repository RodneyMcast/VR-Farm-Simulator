using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;

public class TractorSteeringDrive : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private UnityEngine.XR.Interaction.Toolkit.Interactables.XRGrabInteractable steeringWheelGrab;
    [SerializeField] private Transform steeringWheelVisual; // the wheel mesh transform
    [SerializeField] private Rigidbody tractorRb;

    [Header("Drive Settings")]
    [SerializeField] private float driveSpeed = 2.5f;      // units/sec
    [SerializeField] private float turnSpeed = 60f;        // degrees/sec at full steer

    [Header("Wheel Settings")]
    [SerializeField] private float maxWheelAngle = 90f;    // clamp wheel rotation
    [SerializeField] private float wheelReturnSpeed = 120f; // wheel returns when released

    private bool isHeld = false;

    private float startWheelYaw;
    private float wheelYawOffset; // how much wheel has turned from start
    private Quaternion wheelStartLocalRot;

    private void Reset()
    {
        tractorRb = GetComponent<Rigidbody>();
    }

    private void Awake()
    {
        if (tractorRb == null) tractorRb = GetComponent<Rigidbody>();
        wheelStartLocalRot = steeringWheelVisual.localRotation;
    }

    private void OnEnable()
    {
        steeringWheelGrab.selectEntered.AddListener(OnGrab);
        steeringWheelGrab.selectExited.AddListener(OnRelease);
    }

    private void OnDisable()
    {
        steeringWheelGrab.selectEntered.RemoveListener(OnGrab);
        steeringWheelGrab.selectExited.RemoveListener(OnRelease);
    }

    private void OnGrab(SelectEnterEventArgs args)
    {
        isHeld = true;

        // Record initial yaw reference when grabbed
        startWheelYaw = GetInteractorYaw(args);
    }

    private void OnRelease(SelectExitEventArgs args)
    {
        isHeld = false;
    }

    private void FixedUpdate()
    {
        if (isHeld)
        {
            // Move forward
            Vector3 forwardMove = transform.forward * driveSpeed;
            tractorRb.linearVelocity = new Vector3(forwardMove.x, tractorRb.linearVelocity.y, forwardMove.z);

            // Turn based on wheel offset
            float steer01 = wheelYawOffset / maxWheelAngle; // -1..1
            float turnThisFrame = steer01 * turnSpeed * Time.fixedDeltaTime;
            tractorRb.MoveRotation(tractorRb.rotation * Quaternion.Euler(0f, turnThisFrame, 0f));
        }
        else
        {
            // Stop smoothly
            tractorRb.linearVelocity = new Vector3(0f, tractorRb.linearVelocity.y, 0f);

            // Return wheel to center visually
            wheelYawOffset = Mathf.MoveTowards(wheelYawOffset, 0f, wheelReturnSpeed * Time.fixedDeltaTime);
            ApplyWheelVisual();
        }
    }

    private void Update()
    {
        if (!isHeld) return;

        // While held: update wheelYawOffset based on controller yaw
        // (simple: compare current interactor yaw vs start yaw)
        float currentYaw = GetInteractorYaw(steeringWheelGrab.interactorsSelecting[0]);
        float delta = Mathf.DeltaAngle(startWheelYaw, currentYaw);

        wheelYawOffset = Mathf.Clamp(delta, -maxWheelAngle, maxWheelAngle);
        ApplyWheelVisual();
    }

    private float GetInteractorYaw(SelectEnterEventArgs args)
    {
        return GetInteractorYaw(args.interactorObject);
    }

    private float GetInteractorYaw(UnityEngine.XR.Interaction.Toolkit.Interactors.IXRSelectInteractor interactor)
    {
        Transform t = interactor.transform;
        return t.eulerAngles.y;
    }

    private void ApplyWheelVisual()
    {
        // Rotate wheel around its local Z axis (common for steering wheels)
        steeringWheelVisual.localRotation = wheelStartLocalRot * Quaternion.Euler(0f, -wheelYawOffset, 0f);


    }
}
